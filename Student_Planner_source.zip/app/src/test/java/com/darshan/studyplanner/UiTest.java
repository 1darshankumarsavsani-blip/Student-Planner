package com.darshan.studyplanner;

import static org.junit.Assert.*;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34, qualifiers = "w393dp-h852dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class UiTest {
    static void shot(MainActivity a, String name) throws Exception {
        String dir = System.getProperty("shots.dir", "build/screenshots");
        new File(dir).mkdirs();
        View root = a.getWindow().getDecorView();
        int w = 1179, h = 2556;
        root.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY));
        root.layout(0, 0, w, h);
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        root.draw(new Canvas(bmp));
        try (FileOutputStream o = new FileOutputStream(new File(dir, name))) { bmp.compress(Bitmap.CompressFormat.PNG, 100, o); }
    }

    @Test
    public void walkThroughAllScreens() throws Exception {
        MainActivity a = Robolectric.buildActivity(MainActivity.class).setup().get();
        L.gu = true;
        a.st.setLang("gu");
        // exams
        JSONObject e = new JSONObject();
        e.put("subject", "Python");
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.add(java.util.Calendar.DAY_OF_MONTH, 5);
        e.put("date", MainActivity.ISO.format(c.getTime()));
        a.st.arr("exams").put(e);
        JSONObject e2 = new JSONObject();
        e2.put("subject", ".NET");
        c.add(java.util.Calendar.DAY_OF_MONTH, 20);
        e2.put("date", MainActivity.ISO.format(c.getTime()));
        a.st.arr("exams").put(e2);
        a.render();
        shot(a, "1_exams_gu.png");
        // syllabus
        JSONObject s = new JSONObject();
        s.put("name", "Python");
        org.json.JSONArray tp = new org.json.JSONArray();
        String[] names = {"Loops", "Functions", "OOP", "File handling"};
        for (int i = 0; i < names.length; i++) { JSONObject t = new JSONObject(); t.put("t", names[i]); t.put("done", i < 2); tp.put(t); }
        s.put("topics", tp);
        a.st.arr("subjects").put(s);
        a.tab = 1; a.render();
        shot(a, "2_syllabus_gu.png");
        assertTrue(a.content.getChildCount() >= 2);
        // timer
        a.tab = 2; a.render();
        Button start = a.startBtn;
        assertNotNull(start);
        start.performClick();
        assertTrue(a.running);
        a.resetTimer();
        assertFalse(a.running);
        shot(a, "3_timer_gu.png");
        // notes
        JSONObject n = new JSONObject();
        n.put("title", "Exam tips");
        n.put("body", "Revise OOP and file handling before Monday.");
        a.st.arr("notes").put(n);
        a.tab = 3; a.render();
        shot(a, "4_notes_gu.png");
        // english
        L.gu = false; a.tab = 0; a.render();
        shot(a, "5_exams_en.png");
        assertEquals("Student Planner", L.t("app"));
        // countdown math
        assertEquals(5, MainActivity.daysLeft(MainActivity.ISO.format(java.util.Calendar.getInstance().getTime())) + 5);
        // persistence
        a.st.save();
        Store again = new Store(a);
        assertEquals(2, again.arr("exams").length());
    }
}
