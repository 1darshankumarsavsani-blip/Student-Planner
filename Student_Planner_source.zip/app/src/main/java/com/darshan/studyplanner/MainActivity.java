package com.darshan.studyplanner;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends Activity {
    static final int CORAL = 0xFFFF5A5F, BG = 0xFFF6F5F7, INK = 0xFF1B1B1F, MUTED = 0xFF6B6B76;
    static final int GREEN = 0xFF1E9E63, AMBER = 0xFFE8A200, RED = 0xFFD64545, BLUE = 0xFF0F90FF;
    static final long FOCUS_MS = 25 * 60 * 1000L, BREAK_MS = 5 * 60 * 1000L;

    Store st;
    LinearLayout content, nav;
    TextView title;
    Button langBtn;
    int tab = 0;

    // timer state lives in the activity so it keeps running while you look at other tabs
    long remain = FOCUS_MS;
    boolean running = false, focusMode = true;
    CountDownTimer cdt;
    TextView timerView;
    Button startBtn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        st = new Store(this);
        L.gu = st.lang().equals("gu");
        getWindow().setStatusBarColor(CORAL);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout head = Ui.row(this);
        head.setBackgroundColor(CORAL);
        head.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
        title = Ui.text(this, "", 20, Color.WHITE, true);
        head.addView(title, Ui.weight(1));
        langBtn = Ui.button(this, "", 0x33FFFFFF, Color.WHITE, v -> {
            L.gu = !L.gu;
            st.setLang(L.gu ? "gu" : "en");
            render();
        });
        head.addView(langBtn);
        root.addView(head, Ui.match());

        ScrollView sv = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14));
        sv.addView(content, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        nav = Ui.row(this);
        nav.setBackgroundColor(Color.WHITE);
        nav.setPadding(Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6));
        root.addView(nav, Ui.match());

        setContentView(root);
        render();
    }

    @Override
    protected void onDestroy() {
        if (cdt != null) cdt.cancel();
        super.onDestroy();
    }

    // ---------------------------------------------------------------- shell

    void render() {
        title.setText(L.t("app"));
        langBtn.setText(L.t("lang_btn"));
        nav.removeAllViews();
        String[] keys = {"tab_exams", "tab_syllabus", "tab_timer", "tab_notes"};
        for (int i = 0; i < keys.length; i++) {
            final int idx = i;
            boolean sel = i == tab;
            Button x = Ui.button(this, L.t(keys[i]), sel ? CORAL : Color.TRANSPARENT, sel ? Color.WHITE : MUTED, v -> { tab = idx; render(); });
            x.setTextSize(13);
            x.setPadding(Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8));
            LinearLayout.LayoutParams lp = Ui.weight(1);
            lp.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0);
            nav.addView(x, lp);
        }
        content.removeAllViews();
        timerView = null;
        startBtn = null;
        if (tab == 0) exams();
        else if (tab == 1) syllabus();
        else if (tab == 2) timer();
        else notes();
    }

    Button primary(String s, View.OnClickListener l) {
        Button x = Ui.button(this, "+  " + s, CORAL, Color.WHITE, l);
        LinearLayout.LayoutParams lp = Ui.match();
        lp.setMargins(0, 0, 0, Ui.dp(this, 12));
        x.setLayoutParams(lp);
        return x;
    }

    TextView empty(String s) {
        TextView t = Ui.text(this, s, 15, MUTED, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(this, 30), 0, 0);
        return t;
    }

    EditText input(String hint, boolean multi) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(16);
        if (multi) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            e.setMinLines(5);
            e.setGravity(Gravity.TOP);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            e.setSingleLine(true);
        }
        return e;
    }

    LinearLayout dialogBox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(Ui.dp(this, 20), Ui.dp(this, 10), Ui.dp(this, 20), 0);
        return l;
    }

    void ask(String message, Runnable yes) {
        new AlertDialog.Builder(this).setMessage(message)
                .setPositiveButton(L.t("yes"), (d, w) -> yes.run())
                .setNegativeButton(L.t("cancel"), null).show();
    }

    void oneName(String dialogTitle, String hint, java.util.function.Consumer<String> done) {
        LinearLayout box = dialogBox();
        final EditText e = input(hint, false);
        box.addView(e);
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle(dialogTitle).setView(box)
                .setPositiveButton(L.t("save"), null).setNegativeButton(L.t("cancel"), null).create();
        dlg.setOnShowListener(x -> dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String s = e.getText().toString().trim();
            if (s.isEmpty()) { Toast.makeText(this, L.t("need_name"), Toast.LENGTH_SHORT).show(); return; }
            dlg.dismiss();
            done.accept(s);
        }));
        dlg.show();
    }

    // ---------------------------------------------------------------- exams

    static final SimpleDateFormat ISO = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    static int daysLeft(String iso) {
        try {
            Calendar t = Calendar.getInstance();
            t.set(Calendar.HOUR_OF_DAY, 0); t.set(Calendar.MINUTE, 0); t.set(Calendar.SECOND, 0); t.set(Calendar.MILLISECOND, 0);
            Date d = ISO.parse(iso);
            return (int) Math.round((d.getTime() - t.getTimeInMillis()) / 86400000.0);
        } catch (Exception e) { return 0; }
    }

    static String pretty(String iso) {
        try { return new SimpleDateFormat("dd MMM yyyy", Locale.US).format(ISO.parse(iso)); } catch (Exception e) { return iso; }
    }

    void exams() {
        content.addView(primary(L.t("add_exam"), v -> addExam()));
        JSONArray a = st.arr("exams");
        ArrayList<JSONObject> list = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) list.add(a.optJSONObject(i));
        Collections.sort(list, new Comparator<JSONObject>() {
            public int compare(JSONObject x, JSONObject y) { return x.optString("date").compareTo(y.optString("date")); }
        });
        if (list.isEmpty()) { content.addView(empty(L.t("no_exams"))); return; }
        for (final JSONObject o : list) {
            LinearLayout card = Ui.card(this);
            LinearLayout r = Ui.row(this);
            LinearLayout left = new LinearLayout(this);
            left.setOrientation(LinearLayout.VERTICAL);
            left.addView(Ui.text(this, o.optString("subject"), 18, INK, true));
            left.addView(Ui.text(this, pretty(o.optString("date")), 14, MUTED, false));
            r.addView(left, Ui.weight(1));
            int n = daysLeft(o.optString("date"));
            String chip; int col;
            if (n < 0) { chip = L.t("done"); col = MUTED; }
            else if (n == 0) { chip = L.t("today"); col = RED; }
            else { chip = String.format(Locale.US, L.t("days_left"), n); col = n <= 3 ? RED : (n <= 7 ? AMBER : GREEN); }
            TextView c = Ui.text(this, chip, 14, Color.WHITE, true);
            c.setBackground(Ui.box(this, col, 20, 0));
            c.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
            r.addView(c);
            TextView x = Ui.text(this, "  \u2715", 18, MUTED, true);
            x.setPadding(Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 6));
            x.setOnClickListener(v -> ask(L.t("sure"), () -> { remove(a, o); st.save(); render(); }));
            r.addView(x);
            card.addView(r);
            content.addView(card);
        }
    }

    static void remove(JSONArray a, JSONObject o) {
        for (int i = 0; i < a.length(); i++) if (a.optJSONObject(i) == o) { a.remove(i); return; }
    }

    void addExam() {
        LinearLayout box = dialogBox();
        final EditText e = input(L.t("subject"), false);
        box.addView(e);
        final String[] date = {null};
        final Button pick = Ui.button(this, L.t("pick_date"), 0xFFEFEDF2, INK, null);
        LinearLayout.LayoutParams lp = Ui.match();
        lp.setMargins(0, Ui.dp(this, 12), 0, 0);
        box.addView(pick, lp);
        pick.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            c.add(Calendar.DAY_OF_MONTH, 7);
            new DatePickerDialog(this, (view, y, m, d) -> {
                Calendar s = Calendar.getInstance();
                s.set(y, m, d);
                date[0] = ISO.format(s.getTime());
                pick.setText(pretty(date[0]));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle(L.t("add_exam")).setView(box)
                .setPositiveButton(L.t("save"), null).setNegativeButton(L.t("cancel"), null).create();
        dlg.setOnShowListener(x -> dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String s = e.getText().toString().trim();
            if (s.isEmpty()) { Toast.makeText(this, L.t("need_name"), Toast.LENGTH_SHORT).show(); return; }
            if (date[0] == null) { Toast.makeText(this, L.t("pick_date"), Toast.LENGTH_SHORT).show(); return; }
            try {
                JSONObject o = new JSONObject();
                o.put("subject", s);
                o.put("date", date[0]);
                st.arr("exams").put(o);
            } catch (JSONException ignored) { }
            st.save();
            dlg.dismiss();
            render();
        }));
        dlg.show();
    }

    // ---------------------------------------------------------------- syllabus

    void syllabus() {
        content.addView(primary(L.t("add_subject"), v -> oneName(L.t("add_subject"), L.t("subject"), s -> {
            try {
                JSONObject o = new JSONObject();
                o.put("name", s);
                o.put("topics", new JSONArray());
                st.arr("subjects").put(o);
            } catch (JSONException ignored) { }
            st.save();
            render();
        })));
        final JSONArray subs = st.arr("subjects");
        if (subs.length() == 0) { content.addView(empty(L.t("no_subjects"))); return; }
        for (int i = 0; i < subs.length(); i++) {
            final JSONObject sub = subs.optJSONObject(i);
            final JSONArray topics = sub.optJSONArray("topics");
            int done = 0;
            for (int k = 0; k < topics.length(); k++) if (topics.optJSONObject(k).optBoolean("done")) done++;
            int pct = topics.length() == 0 ? 0 : Math.round(100f * done / topics.length());

            LinearLayout card = Ui.card(this);
            LinearLayout head = Ui.row(this);
            head.addView(Ui.text(this, sub.optString("name"), 18, INK, true), Ui.weight(1));
            head.addView(Ui.text(this, String.format(Locale.US, L.t("progress"), pct), 14, pct == 100 ? GREEN : BLUE, true));
            TextView x = Ui.text(this, "  \u2715", 18, MUTED, true);
            x.setPadding(Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 6));
            x.setOnClickListener(v -> ask(L.t("sure"), () -> { remove(subs, sub); st.save(); render(); }));
            head.addView(x);
            card.addView(head);
            ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            pb.setMax(100);
            pb.setProgress(pct);
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 8));
            pl.setMargins(0, Ui.dp(this, 8), 0, Ui.dp(this, 6));
            card.addView(pb, pl);
            if (topics.length() == 0) card.addView(Ui.text(this, L.t("no_topics"), 14, MUTED, false));
            for (int k = 0; k < topics.length(); k++) {
                final JSONObject tp = topics.optJSONObject(k);
                LinearLayout r = Ui.row(this);
                CheckBox cb = new CheckBox(this);
                cb.setText(tp.optString("t"));
                cb.setTextSize(16);
                cb.setTextColor(INK);
                cb.setChecked(tp.optBoolean("done"));
                cb.setOnCheckedChangeListener((bv, on) -> {
                    try { tp.put("done", on); } catch (JSONException ignored) { }
                    st.save();
                    render();
                });
                r.addView(cb, Ui.weight(1));
                TextView rx = Ui.text(this, "\u2715", 15, MUTED, true);
                rx.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 6));
                rx.setOnClickListener(v -> ask(L.t("sure"), () -> { remove(topics, tp); st.save(); render(); }));
                r.addView(rx);
                card.addView(r);
            }
            Button add = Ui.button(this, "+  " + L.t("add_topic"), 0xFFEFEDF2, INK, v -> oneName(L.t("add_topic"), L.t("topic"), s -> {
                try {
                    JSONObject o = new JSONObject();
                    o.put("t", s);
                    o.put("done", false);
                    topics.put(o);
                } catch (JSONException ignored) { }
                st.save();
                render();
            }));
            LinearLayout.LayoutParams al = Ui.match();
            al.setMargins(0, Ui.dp(this, 8), 0, 0);
            card.addView(add, al);
            content.addView(card);
        }
    }

    // ---------------------------------------------------------------- timer

    static String mmss(long ms) {
        long s = Math.max(0, (ms + 999) / 1000);
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60);
    }

    void timer() {
        LinearLayout card = Ui.card(this);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(Ui.dp(this, 14), Ui.dp(this, 28), Ui.dp(this, 14), Ui.dp(this, 28));
        TextView mode = Ui.text(this, L.t(focusMode ? "focus" : "break"), 18, focusMode ? CORAL : GREEN, true);
        mode.setGravity(Gravity.CENTER);
        card.addView(mode, Ui.match());
        timerView = Ui.text(this, mmss(remain), 64, INK, true);
        timerView.setGravity(Gravity.CENTER);
        card.addView(timerView, Ui.match());
        LinearLayout r = Ui.row(this);
        r.setGravity(Gravity.CENTER);
        startBtn = Ui.button(this, L.t(running ? "pause" : "start"), CORAL, Color.WHITE, v -> toggleTimer());
        r.addView(startBtn);
        Button rs = Ui.button(this, L.t("reset"), 0xFFEFEDF2, INK, v -> resetTimer());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(Ui.dp(this, 12), 0, 0, 0);
        r.addView(rs, lp);
        LinearLayout.LayoutParams rl = Ui.match();
        rl.setMargins(0, Ui.dp(this, 20), 0, 0);
        card.addView(r, rl);
        content.addView(card);
        TextView s = Ui.text(this, String.format(Locale.US, L.t("sessions"), st.sessionsToday()), 16, INK, true);
        s.setGravity(Gravity.CENTER);
        content.addView(s, Ui.match());
        TextView n = Ui.text(this, L.t("timer_note"), 13, MUTED, false);
        n.setGravity(Gravity.CENTER);
        n.setPadding(0, Ui.dp(this, 8), 0, 0);
        content.addView(n, Ui.match());
    }

    void toggleTimer() {
        if (running) {
            cdt.cancel();
            running = false;
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            if (startBtn != null) startBtn.setText(L.t("start"));
            return;
        }
        running = true;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (startBtn != null) startBtn.setText(L.t("pause"));
        cdt = new CountDownTimer(remain, 250) {
            public void onTick(long ms) {
                remain = ms;
                if (timerView != null) timerView.setText(mmss(ms));
            }
            public void onFinish() {
                running = false;
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                if (focusMode) {
                    st.addSession();
                    Toast.makeText(MainActivity.this, L.t("focus_done"), Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, L.t("break_done"), Toast.LENGTH_LONG).show();
                }
                focusMode = !focusMode;
                remain = focusMode ? FOCUS_MS : BREAK_MS;
                if (tab == 2) render();
            }
        }.start();
    }

    void resetTimer() {
        if (cdt != null) cdt.cancel();
        running = false;
        focusMode = true;
        remain = FOCUS_MS;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        render();
    }

    // ---------------------------------------------------------------- notes

    void notes() {
        content.addView(primary(L.t("add_note"), v -> editNote(null)));
        final JSONArray a = st.arr("notes");
        if (a.length() == 0) { content.addView(empty(L.t("no_notes"))); return; }
        for (int i = a.length() - 1; i >= 0; i--) {
            final JSONObject o = a.optJSONObject(i);
            LinearLayout card = Ui.card(this);
            String t = o.optString("title");
            card.addView(Ui.text(this, t.isEmpty() ? L.t("untitled") : t, 17, INK, true));
            TextView body = Ui.text(this, o.optString("body"), 14, MUTED, false);
            body.setMaxLines(3);
            body.setEllipsize(TextUtils.TruncateAt.END);
            card.addView(body);
            card.setOnClickListener(v -> editNote(o));
            content.addView(card);
        }
    }

    void editNote(final JSONObject existing) {
        LinearLayout box = dialogBox();
        final EditText t = input(L.t("note_title"), false);
        final EditText b = input(L.t("note_body"), true);
        if (existing != null) { t.setText(existing.optString("title")); b.setText(existing.optString("body")); }
        box.addView(t);
        box.addView(b);
        AlertDialog.Builder bld = new AlertDialog.Builder(this).setTitle(L.t(existing == null ? "add_note" : "edit_note")).setView(box)
                .setPositiveButton(L.t("save"), (d, w) -> {
                    String ts = t.getText().toString().trim(), bs = b.getText().toString().trim();
                    if (ts.isEmpty() && bs.isEmpty()) return;
                    try {
                        JSONObject o = existing != null ? existing : new JSONObject();
                        o.put("title", ts);
                        o.put("body", bs);
                        if (existing == null) st.arr("notes").put(o);
                    } catch (JSONException ignored) { }
                    st.save();
                    render();
                })
                .setNegativeButton(L.t("cancel"), null);
        if (existing != null) bld.setNeutralButton(L.t("delete"), (d, w) -> ask(L.t("sure"), () -> { remove(st.arr("notes"), existing); st.save(); render(); }));
        bld.show();
    }
}
