package com.darshan.studyplanner;

import java.util.HashMap;
import java.util.Map;

/** Gujarati + English texts. */
final class L {
    private L() {}
    static boolean gu = true;
    private static final Map<String, String[]> M = new HashMap<>();
    private static void p(String k, String g, String e) { M.put(k, new String[]{g, e}); }
    static {
        p("app", "વિદ્યાર્થી પ્લાનર", "Student Planner");
        p("tab_exams", "પરીક્ષા", "Exams");
        p("tab_syllabus", "અભ્યાસક્રમ", "Syllabus");
        p("tab_timer", "ટાઇમર", "Timer");
        p("tab_notes", "નોંધ", "Notes");
        p("lang_btn", "English", "ગુજરાતી");
        p("add", "ઉમેરો", "Add");
        p("cancel", "રદ કરો", "Cancel");
        p("save", "સાચવો", "Save");
        p("delete", "કાઢી નાખો", "Delete");
        p("yes", "હા", "Yes");
        p("sure", "કાઢી નાખવું છે?", "Delete this?");
        p("add_exam", "પરીક્ષા ઉમેરો", "Add exam");
        p("subject", "વિષયનું નામ", "Subject name");
        p("pick_date", "તારીખ પસંદ કરો", "Pick date");
        p("need_name", "નામ લખો", "Enter a name");
        p("days_left", "%d દિવસ બાકી", "%d days left");
        p("today", "આજે પરીક્ષા!", "Exam today!");
        p("done", "પૂરી થઈ", "Finished");
        p("no_exams", "હજી કોઈ પરીક્ષા નથી. ઉપર પરીક્ષા ઉમેરો.", "No exams yet. Add one above.");
        p("add_subject", "વિષય ઉમેરો", "Add subject");
        p("add_topic", "ટોપિક ઉમેરો", "Add topic");
        p("topic", "ટોપિકનું નામ", "Topic name");
        p("progress", "%d%% પૂર્ણ", "%d%% done");
        p("no_subjects", "હજી કોઈ વિષય નથી. ઉપર વિષય ઉમેરો.", "No subjects yet. Add one above.");
        p("no_topics", "હજી કોઈ ટોપિક નથી.", "No topics yet.");
        p("focus", "અભ્યાસનો સમય", "Focus time");
        p("break", "થોડો આરામ", "Break time");
        p("start", "શરૂ કરો", "Start");
        p("pause", "રોકો", "Pause");
        p("reset", "ફરીથી", "Reset");
        p("sessions", "આજના અભ્યાસ સેશન: %d", "Study sessions today: %d");
        p("timer_note", "ટાઇમર ચાલુ હોય ત્યારે app બંધ ન કરશો.", "Keep the app open while the timer runs.");
        p("focus_done", "શાબાશ! 25 મિનિટ પૂરી. હવે 5 મિનિટ આરામ.", "Well done! 25 minutes finished. Take a 5 minute break.");
        p("break_done", "આરામ પૂરો. ફરી અભ્યાસ શરૂ કરો.", "Break over. Back to studying.");
        p("add_note", "નોંધ ઉમેરો", "Add note");
        p("edit_note", "નોંધ સુધારો", "Edit note");
        p("note_title", "શીર્ષક", "Title");
        p("note_body", "અહીં નોંધ લખો", "Write your note here");
        p("no_notes", "હજી કોઈ નોંધ નથી. ઉપર નોંધ ઉમેરો.", "No notes yet. Add one above.");
        p("untitled", "(શીર્ષક વગર)", "(Untitled)");
    }
    static String t(String k) {
        String[] v = M.get(k);
        return v == null ? k : v[gu ? 0 : 1];
    }
}
